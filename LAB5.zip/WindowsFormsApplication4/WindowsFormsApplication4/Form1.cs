﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class Form1 : Form
    {
        int z = 0;
        public Form1()
        {
            InitializeComponent();
        }


        private void add_Click(object sender, EventArgs e)
        {
            z = z + 1;
            label.Text = Convert.ToString(z);
        }

        private void reset_Click(object sender, EventArgs e)
        {
            z = 0;
            label.Text = Convert.ToString(z);
            
        }

        private void quit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label_Click(object sender, EventArgs e)
        {

        }
    }
}
